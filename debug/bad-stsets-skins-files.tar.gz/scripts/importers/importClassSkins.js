import fs from "fs";
import path from "path";
import axios from "axios";
import * as cheerio from "cheerio";

const BASE_URL = "https://www.realmeye.com";
const SOURCE_PATHS = ["/wiki/skins", "/wiki/class-skins", "/wiki/character-skins"];
const SKINS_JSON = "src/data/class-skins.json";
const SKINS_IMG_DIR = "public/skins";
const DEBUG_DIR = "debug";
const CANDIDATES_JSON = path.join(DEBUG_DIR, "class-skin-candidates.json");

fs.mkdirSync(SKINS_IMG_DIR, { recursive: true });
fs.mkdirSync(DEBUG_DIR, { recursive: true });

function slugify(text) {
  return String(text || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/['’]/g, "")
    .replace(/[^a-zA-Z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .toLowerCase();
}

function cleanText(text) {
  return String(text || "").replace(/\s+/g, " ").trim();
}

function absoluteUrl(url) {
  if (!url) return "";
  if (url.startsWith("http")) return url;
  if (url.startsWith("//")) return `https:${url}`;
  if (url.startsWith("/")) return `${BASE_URL}${url}`;
  return `${BASE_URL}/${url}`;
}

async function fetchPage(url) {
  const response = await axios.get(url, {
    headers: { "User-Agent": "Mozilla/5.0" },
    validateStatus: () => true,
  });
  return response;
}

async function downloadImage(url, outputPath) {
  if (!url) return false;
  try {
    const response = await axios.get(url, {
      responseType: "arraybuffer",
      headers: { "User-Agent": "Mozilla/5.0" },
    });
    fs.writeFileSync(outputPath, response.data);
    return true;
  } catch {
    return false;
  }
}

function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function findSourcePage() {
  return Promise.all(
    SOURCE_PATHS.map(async (pathName) => {
      const url = `${BASE_URL}${pathName}`;
      const response = await fetchPage(url);
      if (response.status !== 200) return null;
      const $ = cheerio.load(response.data);
      const title = cleanText($("h1").first().text());
      if (/skin/i.test(title)) {
        return { url, html: response.data };
      }
      return null;
    })
  ).then((results) => results.find((result) => result));
}

function parseSkinsFromCharacterPage(html, sourceUrl) {
  const $ = cheerio.load(html);
  const page = $(".wiki-page");
  const table = page.find("table").eq(1);
  if (!table.length) return [];

  const skins = new Map();
  let currentClass = "Unknown";

  table.find("tr").each((_, row) => {
    const cells = $(row).find("td");
    if (!cells.length) return;

    let skinTier = "";
    let altCell = null;
    let setCell = null;

    if (cells.length === 4) {
      currentClass = cleanText(cells.eq(0).text()) || currentClass;
      skinTier = cleanText(cells.eq(1).text()) || "Unknown";
      altCell = cells.eq(2);
      setCell = cells.eq(3);
    } else if (cells.length === 3) {
      skinTier = cleanText(cells.eq(0).text()) || "Unknown";
      altCell = cells.eq(1);
      setCell = cells.eq(2);
    } else {
      return;
    }

    parseSkinImages(skins, altCell, sourceUrl, currentClass, skinTier);
    parseSkinImages(skins, setCell, sourceUrl, currentClass, "Set Tier");
  });

  return [...skins.values()];
}

function parseSkinImages(skins, cell, sourceUrl, skinClass, rarity) {
  if (!cell) return;
  cell.find("img").each((_, img) => {
    const $img = cheerio(img);
    const alt = cleanText($img.attr("alt") || $img.attr("title") || "");
    if (!alt || alt.toLowerCase() === skinClass.toLowerCase()) return;
    const src = $img.attr("src") || $img.attr("data-src") || $img.attr("data-original") || "";
    if (!src) return;
    const name = alt;
    const slug = slugify(name);
    if (!slug) return;

    const existing = skins.get(slug);
    if (existing) {
      if (!existing.sprite && src) existing.sprite = `/skins/${slug}.png`;
      if (!existing.sourceUrl) existing.sourceUrl = sourceUrl;
      return;
    }

    skins.set(slug, {
      id: slug,
      name,
      slug,
      class: skinClass,
      sprite: `/skins/${slug}.png`,
      rarity: rarity || "Unknown",
      sourceUrl,
      notes: ["Imported from RealmEye Character Skins."],
      spriteUrl: absoluteUrl(src),
    });
  });
}

async function saveSprites(skins) {
  for (const skin of skins) {
    if (!skin.spriteUrl) continue;
    const outputPath = path.join(SKINS_IMG_DIR, `${skin.slug}.png`);
    if (fs.existsSync(outputPath)) continue;
    const ok = await downloadImage(skin.spriteUrl, outputPath);
    if (!ok) {
      console.warn(`Failed to download skin sprite: ${skin.name}`);
    }
  }
}

async function main() {
  const page = await findSourcePage();
  if (!page) {
    console.error("No valid RealmEye skin page found.");
    process.exit(1);
  }

  console.log(`Using skin source page: ${page.url}`);
  const skins = parseSkinsFromCharacterPage(page.html, page.url);

  if (skins.length === 0) {
    console.error("No skin entries were parsed from the source page.");
    process.exit(1);
  }

  const uniqueSkins = new Map();
  for (const skin of skins) {
    if (!uniqueSkins.has(skin.slug)) {
      uniqueSkins.set(skin.slug, {
        id: skin.id,
        name: skin.name,
        slug: skin.slug,
        class: skin.class,
        sprite: skin.sprite,
        rarity: skin.rarity,
        sourceUrl: skin.sourceUrl,
        notes: skin.notes,
      });
    }
  }

  const output = [...uniqueSkins.values()];
  writeJson(SKINS_JSON, output);
  writeJson(CANDIDATES_JSON, output.map((skin) => ({ name: skin.name, slug: skin.slug, class: skin.class, rarity: skin.rarity, sourceUrl: skin.sourceUrl })));
  await saveSprites(output);

  console.log(`Imported ${output.length} class skins.`);
  console.log(`Saved ${SKINS_JSON} and debug file ${CANDIDATES_JSON}.`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
