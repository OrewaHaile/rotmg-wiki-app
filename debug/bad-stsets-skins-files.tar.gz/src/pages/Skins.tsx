import { useMemo, useState } from "react";
import { ExternalLink, Search, Sparkles } from "lucide-react";
import classSkinsData from "../data/class-skins.json";

interface ClassSkin {
  id: string;
  name: string;
  slug: string;
  class: string;
  sprite: string;
  rarity: string;
  sourceUrl: string;
  notes?: string[];
}

const skins = classSkinsData as ClassSkin[];
const classOptions = ["All", ...Array.from(new Set(skins.map((skin) => skin.class))).sort()];

export default function Skins() {
  const [query, setQuery] = useState("");
  const [selectedClass, setSelectedClass] = useState("All");

  const filteredSkins = useMemo(() => {
    return skins
      .filter((skin) => {
        const search = query.trim().toLowerCase();
        return (
          (!search || skin.name.toLowerCase().includes(search) || skin.class.toLowerCase().includes(search)) &&
          (selectedClass === "All" || skin.class === selectedClass)
        );
      })
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [query, selectedClass]);

  return (
    <main className="min-h-screen bg-stone-950 text-stone-100 px-4 py-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <section className="rounded-3xl border border-amber-900/40 bg-[radial-gradient(circle_at_top_left,_rgba(245,158,11,0.12),_transparent_32%),linear-gradient(180deg,_#1c1712_0%,_#0c0a09_100%)] p-6">
          <p className="text-xs font-bold uppercase tracking-[0.35em] text-amber-400/80">
            RotMG Wiki
          </p>

          <div className="mt-3 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h1 className="text-4xl font-black text-amber-100">Class Skins</h1>
              <p className="mt-3 max-w-2xl text-sm leading-6 text-stone-300">
                Browse RealmEye class skins with sprite thumbnails, rarity, and class filters.
              </p>
            </div>

            <div className="rounded-2xl border border-amber-900/40 bg-stone-950/70 px-5 py-4">
              <p className="text-xs uppercase tracking-[0.25em] text-stone-500">Loaded skins</p>
              <p className="mt-2 text-3xl font-black text-amber-200">{skins.length}</p>
            </div>
          </div>
        </section>

        <section className="grid gap-4 lg:grid-cols-[minmax(240px,_320px)_1fr]">
          <div className="space-y-4 rounded-3xl border border-stone-800 bg-stone-950/80 p-4">
            <div className="flex items-center gap-2 text-stone-400">
              <Search className="h-4 w-4 text-amber-300" />
              <span className="text-sm uppercase tracking-[0.25em]">Search</span>
            </div>
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              className="w-full rounded-2xl border border-stone-800 bg-stone-900/70 px-4 py-3 text-sm text-stone-100 outline-none transition focus:border-amber-500/80"
              placeholder="Search by skin name or class"
            />

            <div className="space-y-3 rounded-3xl border border-stone-800 bg-stone-950/80 p-4">
              <p className="text-xs uppercase tracking-[0.25em] text-stone-500">Class filter</p>
              <div className="flex flex-wrap gap-2">
                {classOptions.map((option) => (
                  <button
                    key={option}
                    type="button"
                    onClick={() => setSelectedClass(option)}
                    className={`rounded-full border px-3 py-2 text-sm font-semibold transition ${
                      selectedClass === option
                        ? "border-amber-500 bg-amber-500/10 text-amber-200"
                        : "border-stone-800 bg-stone-900 text-stone-300 hover:border-amber-500/30 hover:text-amber-200"
                    }`}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {filteredSkins.length === 0 ? (
              <section className="rounded-3xl border border-amber-900/40 bg-amber-500/10 p-6">
                <div className="flex items-start gap-3">
                  <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-amber-300" />
                  <div>
                    <h2 className="font-bold text-amber-100">No skins found</h2>
                    <p className="mt-2 text-sm text-amber-100/75">
                      Try adjusting the search or class filter to view class skin entries.
                    </p>
                  </div>
                </div>
              </section>
            ) : (
              <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {filteredSkins.map((skin) => (
                  <article key={skin.id} className="rounded-3xl border border-stone-800 bg-stone-900/80 p-4 shadow-xl shadow-black/20">
                    <div className="flex items-center gap-4">
                      <div className="flex h-20 w-20 items-center justify-center rounded-3xl border border-stone-800 bg-stone-950">
                        {skin.sprite ? (
                          <img
                            src={skin.sprite}
                            alt={skin.name}
                            className="h-16 w-16 object-contain"
                            style={{ imageRendering: "pixelated" }}
                          />
                        ) : (
                          <span className="text-stone-500">?</span>
                        )}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs uppercase tracking-[0.25em] text-stone-500">{skin.class}</p>
                        <h2 className="truncate text-lg font-bold text-amber-100">{skin.name}</h2>
                        <p className="mt-1 text-sm text-stone-400">{skin.rarity || "Unknown"}</p>
                      </div>
                    </div>

                    <div className="mt-4 flex flex-wrap gap-2">
                      {skin.sourceUrl && (
                        <a
                          href={skin.sourceUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-2 rounded-2xl border border-amber-800/50 bg-amber-500/10 px-3 py-2 text-xs font-semibold text-amber-200 transition hover:bg-amber-500/20"
                        >
                          View source
                          <ExternalLink className="h-3.5 w-3.5" />
                        </a>
                      )}
                    </div>
                  </article>
                ))}
              </div>
            )}
          </div>
        </section>
      </div>
    </main>
  );
}
